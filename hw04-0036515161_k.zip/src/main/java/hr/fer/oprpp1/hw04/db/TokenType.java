package hr.fer.oprpp1.hw04.db;

/**
 * Vrste tokena koje stvara lexer.
 */
public enum TokenType {
    ATTRIBUTE,
    OPERATOR,
    STRING_LITERAL,
    AND,
    EOF
}
