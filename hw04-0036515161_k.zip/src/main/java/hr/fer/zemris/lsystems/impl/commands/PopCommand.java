package hr.fer.zemris.lsystems.impl.commands;

import hr.fer.zemris.lsystems.Painter;
import hr.fer.zemris.lsystems.impl.Command;
import hr.fer.zemris.lsystems.impl.Context;

/**
 * Naredba kojom trentuno aktivno stanje spremamo na stog.
 */
public class PopCommand implements Command {

    /**
     * Sprema kopiju trenutnog aktivnog stanja na stog.
     * @param ctx kontekst u kojem su spremljena stanja
     * @param painter <code>Painter</code> koji sadrži funkcije za crtanje po platnu
     */
    @Override
    public void execute(Context ctx, Painter painter) {
        ctx.popState();
    }
}
