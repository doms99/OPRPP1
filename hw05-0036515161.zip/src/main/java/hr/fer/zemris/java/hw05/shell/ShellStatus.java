package hr.fer.zemris.java.hw05.shell;

/**
 * Status that is returned by ShellCommands
 */
public enum ShellStatus {
    CONTINUE, TERMINATE
}
